test_that("rasch_fit returns correctly structured person and item fit data frames", {
  set.seed(42)
  dat  <- matrix(sample(1:5, 120, replace = TRUE), nrow = 24,
                 dimnames = list(paste0("P", 1:24), paste0("I", 1:5)))
  gmat <- guttman_order(dat)
  fit  <- rasch_fit(gmat)

  expect_named(fit, c("person_fit", "item_fit", "pcm_model", "person_params"))
  expect_true(is.data.frame(fit$person_fit))
  expect_true(is.data.frame(fit$item_fit))
  expect_named(fit$person_fit, c("OutfitMSQ", "InfitMSQ", "OutfitZ", "InfitZ"))
  expect_named(fit$item_fit,   c("OutfitMSQ", "InfitMSQ", "OutfitZ", "InfitZ"))
  expect_equal(nrow(fit$person_fit), 24)
  expect_equal(nrow(fit$item_fit),    5)
})

test_that("rasch_fit person_fit row names are a subset of guttman_mat row names", {
  set.seed(3)
  dat  <- matrix(sample(1:5, 100, replace = TRUE), nrow = 20,
                 dimnames = list(paste0("P", 1:20), paste0("I", 1:5)))
  gmat <- guttman_order(dat)
  fit  <- rasch_fit(gmat)
  expect_true(all(rownames(fit$person_fit) %in% rownames(gmat)))
})

test_that("rasch_fit item_fit row names match guttman_mat column names", {
  set.seed(4)
  dat  <- matrix(sample(1:5, 100, replace = TRUE), nrow = 20,
                 dimnames = list(paste0("P", 1:20), paste0("I", 1:5)))
  gmat <- guttman_order(dat)
  fit  <- rasch_fit(gmat)
  expect_equal(sort(rownames(fit$item_fit)), sort(colnames(gmat)))
})

test_that(".patch_erm_pcm inserts .dgesv_patch_applied sentinel into eRm::PCM", {
  # Reset so the patch definitely runs
  .pkg_state$erm_patched <- FALSE
  .patch_erm_pcm()

  ns  <- asNamespace("eRm")
  fn  <- get("PCM", envir = ns)
  src <- paste(deparse(body(fn)), collapse = " ")
  expect_true(grepl(".dgesv_patch_applied", src, fixed = TRUE))
  expect_true(grepl(".H_inv", src, fixed = TRUE))
})

test_that(".patch_erm_pcm is idempotent", {
  # After first patch, flag is TRUE; second call must be a no-op
  .pkg_state$erm_patched <- TRUE
  .patch_erm_pcm()
  expect_true(.pkg_state$erm_patched)
})

test_that("ridge fallback resolves a rank-1 singular matrix", {
  H <- outer(c(1, 2, 3), c(1, 2, 3))   # rank 1
  expect_equal(det(H), 0, tolerance = 1e-10)
  expect_error(base::solve(H))

  n <- nrow(H); res <- NULL
  for (.l in 10^seq(-6, -1)) {
    res <- tryCatch(base::solve(H + diag(.l, n)), error = function(e) NULL)
    if (!is.null(res)) break
  }
  expect_true(is.matrix(res))
  expect_equal(dim(res), c(3L, 3L))
})

test_that("SVD pseudoinverse satisfies H %*% pinv %*% H == H", {
  H    <- outer(c(1, 2, 3), c(1, 2, 3))
  .s   <- base::svd(H)
  .t   <- max(dim(H)) * .Machine$double.eps * max(.s$d)
  pinv <- .s$v %*% diag(ifelse(.s$d > .t, 1/.s$d, 0), length(.s$d)) %*% t(.s$u)
  expect_equal(H %*% pinv %*% H, H, tolerance = 1e-8)
})

test_that("rasch_fit succeeds on depression-survey skewed profile", {
  set.seed(99)
  n <- 80; p <- 10
  probs <- c(0.5, 0.25, 0.12, 0.08, 0.05)
  dat   <- matrix(sample(1:5, n * p, replace = TRUE, prob = probs),
                  nrow = n,
                  dimnames = list(paste0("P", 1:n), paste0("I", 1:p)))
  gmat  <- guttman_order(dat)
  expect_no_error(fit <- rasch_fit(gmat))
  expect_equal(nrow(fit$item_fit), p)
})

test_that("rasch_fit succeeds on large dataset (STAT-173 scale: 441 persons x 30 items)", {
  set.seed(7)
  n <- 441; p <- 30
  probs <- c(0.5, 0.25, 0.12, 0.08, 0.05)
  dat   <- matrix(sample(1:5, n * p, replace = TRUE, prob = probs),
                  nrow = n,
                  dimnames = list(paste0("P", 1:n), paste0("I", 1:p)))
  gmat  <- guttman_order(dat)
  expect_no_error(fit <- rasch_fit(gmat))
  expect_equal(nrow(fit$item_fit), p)
  expect_true(nrow(fit$person_fit) > 0)
})
