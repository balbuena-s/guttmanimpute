#' Read an Ordinal Response Matrix from a File
#'
#' Reads a response matrix from an XLSX or CSV file and returns it as a
#' numeric matrix with persons in rows and items in columns, ready for
#' [guttman_impute()].
#'
#' @section Column layout:
#' The file is expected to have **one row per person** and **one column per
#' item**, with an optional leading person-ID column.  If a leading column is
#' non-numeric (e.g. student IDs, names) it is automatically set as row names
#' and excluded from the data.  If the leading column is numeric it is treated
#' as an item unless `id_col` is set.
#'
#' @section Auto-transpose:
#' When the raw file has **more columns than rows** (i.e. persons appear to be
#' stored as columns rather than rows), the function transposes the matrix
#' automatically and emits an informative message.  Set
#' `auto_transpose = FALSE` to disable this behaviour.
#'
#' @param file Path to an `.xlsx` or `.csv` file.
#' @param id_col Integer column index or column name of the person-ID column,
#'   or `NULL` (default) to detect automatically (any leading non-numeric
#'   column is used as row names).
#' @param sheet Integer or name of the sheet to read for XLSX files.
#'   Default: `1`.
#' @param auto_transpose Logical. If `TRUE` (default), transpose the matrix
#'   when columns outnumber rows (persons stored as columns).
#' @param verbose Logical. If `TRUE` (default), print a summary of what was
#'   read.
#'
#' @return A numeric matrix with persons in rows and items in columns.
#'   Row names are person IDs (from the ID column if present, otherwise
#'   sequential `"P1"`, `"P2"`, ...).
#'
#' @examples
#' \dontrun{
#' # Excel file with persons in rows, optional leading ID column
#' dat <- read_response_data("stat173.xlsx")
#' result <- guttman_impute(dat)
#'
#' # Excel file where persons are stored as columns (auto-transposed)
#' dat <- read_response_data("stat173_transposed.xlsx")
#'
#' # Force a specific ID column by name
#' dat <- read_response_data("stat173.xlsx", id_col = "StudentID")
#' }
#'
#' @export
read_response_data <- function(file,
                                id_col        = NULL,
                                sheet         = 1L,
                                auto_transpose = TRUE,
                                verbose        = TRUE) {

  if (!file.exists(file))
    stop("File not found: ", file, call. = FALSE)

  ext <- tolower(tools::file_ext(file))

  # -- Read raw data --------------------------------------------------------
  if (ext == "xlsx") {
    if (!requireNamespace("openxlsx", quietly = TRUE))
      stop("Package 'openxlsx' is required to read .xlsx files.\n",
           "Install it with: install.packages('openxlsx')", call. = FALSE)
    raw <- openxlsx::read.xlsx(file, sheet = sheet, colNames = TRUE)
  } else if (ext == "csv") {
    raw <- utils::read.csv(file, check.names = FALSE, stringsAsFactors = FALSE)
  } else {
    stop("Unsupported file type '.", ext, "'. Use .xlsx or .csv.", call. = FALSE)
  }

  # -- Identify and extract person-ID column --------------------------------
  person_ids <- NULL

  if (!is.null(id_col)) {
    # User specified the ID column explicitly
    if (is.character(id_col)) {
      if (!id_col %in% colnames(raw))
        stop("id_col '", id_col, "' not found in file columns.", call. = FALSE)
      id_idx <- which(colnames(raw) == id_col)
    } else {
      id_idx <- as.integer(id_col)
    }
    person_ids <- as.character(raw[[id_idx]])
    raw        <- raw[, -id_idx, drop = FALSE]

  } else {
    # Auto-detect: use a leading column if it is non-numeric
    if (ncol(raw) > 1L) {
      first_col <- raw[[1L]]
      if (!suppressWarnings(all(!is.na(as.numeric(as.character(first_col)))))) {
        # First column is not fully numeric -> treat as person IDs
        person_ids <- as.character(first_col)
        raw        <- raw[, -1L, drop = FALSE]
        if (verbose)
          message("[read_response_data] First column used as person IDs.")
      }
    }
  }

  # -- Coerce to numeric matrix ---------------------------------------------
  mat <- tryCatch(
    as.matrix(sapply(raw, as.numeric)),
    warning = function(w) as.matrix(sapply(raw, as.numeric))
  )

  if (!is.numeric(mat))
    stop("Data columns could not be coerced to numeric. ",
         "Check that all item columns contain only numbers.", call. = FALSE)

  rownames(mat) <- if (!is.null(person_ids)) person_ids else
                     paste0("P", seq_len(nrow(mat)))
  colnames(mat) <- colnames(raw)

  # -- Auto-transpose when persons are stored as columns -------------------
  # Heuristic: if ncol >> nrow the file is almost certainly transposed.
  # For a well-formed survey, n_persons > n_items almost always.
  transposed <- FALSE
  if (auto_transpose && ncol(mat) > nrow(mat)) {
    if (verbose)
      message(sprintf(
        "[read_response_data] File has %d rows x %d columns. ",
        nrow(mat), ncol(mat)),
        "Persons appear to be stored as COLUMNS. Transposing automatically.\n",
        "  Set auto_transpose = FALSE to disable this.")
    mat        <- t(mat)
    transposed <- TRUE
  }

  if (verbose) {
    message(sprintf(
      "[read_response_data] Read %d persons x %d items%s.",
      nrow(mat), ncol(mat),
      if (transposed) " (transposed)" else ""))
  }

  mat
}
