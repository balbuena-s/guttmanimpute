test_that("read_response_data reads a CSV with persons in rows correctly", {
  # Write a temp CSV: 10 persons x 5 items, no ID col
  set.seed(1)
  mat <- matrix(sample(1:5, 50, replace = TRUE), nrow = 10,
                dimnames = list(NULL, paste0("I", 1:5)))
  tmp <- tempfile(fileext = ".csv")
  write.csv(mat, tmp, row.names = FALSE)

  result <- suppressMessages(read_response_data(tmp, verbose = FALSE))
  expect_equal(dim(result), c(10L, 5L))
  expect_equal(colnames(result), paste0("I", 1:5))
})

test_that("read_response_data strips a non-numeric leading ID column", {
  set.seed(2)
  df <- data.frame(
    StudentID = paste0("STU", 1:8),
    matrix(sample(1:5, 40, replace = TRUE), nrow = 8,
           dimnames = list(NULL, paste0("Item", 1:5))),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  tmp <- tempfile(fileext = ".csv")
  write.csv(df, tmp, row.names = FALSE)

  result <- suppressMessages(read_response_data(tmp, verbose = FALSE))
  expect_equal(dim(result), c(8L, 5L))
  expect_equal(rownames(result), paste0("STU", 1:8))
  expect_equal(colnames(result), paste0("Item", 1:5))
})

test_that("read_response_data auto-transposes when columns > rows", {
  # 5 rows x 20 cols => persons stored as columns => auto-transpose to 20 x 5
  set.seed(3)
  mat_transposed <- matrix(sample(1:5, 100, replace = TRUE), nrow = 5,
                           dimnames = list(paste0("I", 1:5),
                                           paste0("P", 1:20)))
  tmp <- tempfile(fileext = ".csv")
  write.csv(mat_transposed, tmp, row.names = TRUE)

  # After reading the CSV with row.names, we get 5 rows x 20 cols (still transposed)
  # But read_response_data detects ncol > nrow and transposes back
  result <- suppressMessages(
    read_response_data(tmp, id_col = 1L, verbose = FALSE))
  expect_equal(nrow(result), 20L)   # persons
  expect_equal(ncol(result), 5L)    # items
})

test_that("read_response_data errors on non-existent file", {
  expect_error(read_response_data("does_not_exist.csv"), "File not found")
})

test_that("read_response_data errors on unsupported extension", {
  tmp <- tempfile(fileext = ".tsv")
  writeLines("a\tb\n1\t2", tmp)
  expect_error(read_response_data(tmp), "Unsupported file type")
})

test_that("read_response_data reads XLSX with persons in rows", {
  set.seed(4)
  mat <- matrix(sample(1:5, 60, replace = TRUE), nrow = 12,
                dimnames = list(paste0("P", 1:12), paste0("I", 1:5)))
  tmp <- tempfile(fileext = ".xlsx")
  openxlsx::write.xlsx(
    data.frame(PersonID = rownames(mat), as.data.frame(mat), check.names = FALSE),
    tmp, rowNames = FALSE)

  result <- suppressMessages(read_response_data(tmp, verbose = FALSE))
  expect_equal(dim(result), c(12L, 5L))
  expect_equal(rownames(result), paste0("P", 1:12))
})
