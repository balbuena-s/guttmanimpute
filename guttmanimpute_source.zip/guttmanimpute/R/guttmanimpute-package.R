#' @keywords internal
#' @aliases guttmanimpute-package
"_PACKAGE"

#' @importFrom eRm PCM person.parameter personfit itemfit
NULL

#' @importFrom openxlsx read.xlsx write.xlsx
#' @importFrom utils assignInNamespace read.csv write.csv
NULL
