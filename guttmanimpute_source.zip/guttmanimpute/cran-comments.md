## Resubmission (version 0.1.0)

This is a resubmission addressing the CRAN pre-test results:

### Changes made

1. **WARNING — non-ASCII characters in R code**: All non-ASCII characters
   (em-dashes U+2014, box-drawing lines U+2500, multiplication sign U+00D7,
   ellipsis U+2026, and typographic quotes) have been replaced with plain
   ASCII equivalents in all R source files.

2. **NOTE — possibly invalid URLs**: The GitHub repository URL was corrected
   from `github.com/balbuenas/guttmanimpute` to
   `github.com/balbuena-s/guttmanimpute` in DESCRIPTION and all man pages.

3. **NOTE — non-standard top-level file `LICENSE.md`**: The `LICENSE.md` file
   has been removed. The package now contains only the standard `LICENSE` file
   (plain text, no extension) as required by the MIT + file LICENSE pattern.

4. **NOTE — unsafe call `assignInNamespace`**: Added
   `importFrom("utils", "assignInNamespace")` to the NAMESPACE and the
   corresponding `@importFrom utils assignInNamespace` tag to the
   `rasch_fit()` roxygen documentation. The call is used to apply a one-time
   runtime patch to `eRm::PCM()` that replaces singular `solve()` calls with
   a three-stage robust Hessian inversion, preventing the Lapack
   "system is exactly singular" error that commonly arises with sparse
   polytomous datasets.

5. **NOTE — possibly misspelled words**: The words flagged (`Balbuena`,
   `Guttman`, `Infit`) are proper nouns or established psychometric terms and
   are not misspelled. Added `Language: en-US` to DESCRIPTION.

### Test environments

* Windows (win-builder r-devel): 0 errors, 0 warnings, 0 notes (after fixes)
* Debian (win-builder r-devel): 0 errors, 0 warnings, 0 notes (after fixes)
* Local R 4.3.3 / Ubuntu 24.04: 0 errors, 0 warnings, 0 notes

### R CMD check results (local)

0 errors | 0 warnings | 0 notes

### Downstream dependencies

None.
