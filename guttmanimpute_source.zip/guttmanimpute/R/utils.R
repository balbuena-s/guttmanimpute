# Internal utility functions -- not exported

# .extract_id_col(data, id_col)
#
# Extracts the person-ID column from a data frame, sets it as row names,
# and returns the numeric-only data frame/matrix.
#
# @param data  A data frame or matrix.
# @param id_col Column name (character) or index (integer) of the ID column.
#               If NULL, no extraction is performed.
# @return A list with:
#   $data     - data with the ID column removed (still a data.frame or matrix)
#   $ids      - character vector of person IDs (or NULL if id_col was NULL)
.extract_id_col <- function(data, id_col) {

  if (is.null(id_col)) return(list(data = data, ids = NULL))

  if (!is.data.frame(data) && !is.matrix(data))
    stop("`data` must be a data frame or matrix.", call. = FALSE)

  # Resolve id_col to a column index
  if (is.character(id_col)) {
    if (!id_col %in% colnames(data))
      stop("id_col '", id_col, "' not found in the data. ",
           "Available columns: ", paste(colnames(data), collapse = ", "),
           call. = FALSE)
    idx <- which(colnames(data) == id_col)
  } else if (is.numeric(id_col)) {
    idx <- as.integer(id_col)
    if (idx < 1L || idx > ncol(data))
      stop("id_col index ", idx, " is out of range (data has ",
           ncol(data), " columns).", call. = FALSE)
  } else {
    stop("`id_col` must be a column name (character) or index (integer).",
         call. = FALSE)
  }

  # Use [, idx] not [[idx]]: for matrices [[integer]] is element-wise not column-wise
  ids  <- as.character(data[, idx])
  data <- data[, -idx, drop = FALSE]

  list(data = data, ids = ids)
}


# .to_matrix(data, ids)
#
# Coerces data to a numeric matrix and assigns person IDs as row names.
# Row names are taken from `ids` if supplied, otherwise from existing
# rownames, otherwise synthetic "P1", "P2", ... labels are assigned.
.to_matrix <- function(data, ids = NULL) {

  if (!is.matrix(data) && !is.data.frame(data))
    stop("`data` must be a numeric matrix or data frame.", call. = FALSE)

  # Capture names before coercion
  orig_rn <- if (!is.null(ids)) ids else rownames(data)
  orig_cn <- colnames(data)

  mat <- as.matrix(data)

  # If matrix is not numeric, attempt silent coercion first.
  # This handles the common mistake of using cbind() to attach a PersonID
  # column (cbind coerces the whole matrix to character).  Coercion succeeds
  # when every element is a numeric string; it fails (produces NAs) when a
  # genuinely non-numeric column is still present.
  if (!is.numeric(mat)) {
    mat_num <- suppressWarnings(
      matrix(as.numeric(mat), nrow = nrow(mat), dimnames = dimnames(mat))
    )
    if (anyNA(mat_num) && !anyNA(mat)) {
      # Coercion introduced new NAs -> truly non-numeric content remains
      stop(
        "`data` must contain only numeric values after the person-ID column ",
        "has been removed.\n",
        "Common causes:\n",
        "  (a) A non-numeric column is still present. Did you forget id_col?\n",
        "  (b) cbind() was used to attach the ID column -- this silently coerces\n",
        "      all values to character. Use data.frame() instead:\n",
        "        dat_df <- data.frame(PersonID = rownames(dat), dat,\n",
        "                             check.names = FALSE)\n",
        "        guttman_impute(dat_df, id_col = \"PersonID\", ...)",
        call. = FALSE
      )
    }
    warning(
      "[guttmanimpute] Response matrix was character-typed and has been ",
      "coerced to numeric. This usually happens when cbind() is used to ",
      "attach an ID column. Use data.frame() to avoid this:\n",
      "  dat_df <- data.frame(PersonID = rownames(dat), dat, check.names = FALSE)",
      call. = FALSE
    )
    mat <- mat_num
  }

  rownames(mat) <- orig_rn
  colnames(mat) <- orig_cn

  # Only assign synthetic labels when truly absent
  if (is.null(rownames(mat)))
    rownames(mat) <- paste0("P", seq_len(nrow(mat)))
  if (is.null(colnames(mat)))
    colnames(mat) <- paste0("I", seq_len(ncol(mat)))

  mat
}


# .validate_thresholds(msq_lower, msq_upper, z_threshold)
.validate_thresholds <- function(msq_lower, msq_upper, z_threshold) {

  if (!is.numeric(msq_lower) || length(msq_lower) != 1L || msq_lower < 0)
    stop("`msq_lower` must be a single non-negative number.", call. = FALSE)
  if (!is.numeric(msq_upper) || length(msq_upper) != 1L ||
      msq_upper <= msq_lower)
    stop("`msq_upper` must be a single number greater than `msq_lower`.",
         call. = FALSE)
  if (!is.numeric(z_threshold) || length(z_threshold) != 1L ||
      z_threshold <= 0)
    stop("`z_threshold` must be a single positive number.", call. = FALSE)

  invisible(NULL)
}


# .validate_save_path(file)
#
# Checks that the target directory exists and is writable.
.validate_save_path <- function(file) {
  dir_path <- dirname(normalizePath(file, mustWork = FALSE))
  if (!dir.exists(dir_path))
    stop("Directory does not exist: ", dir_path, "\n",
         "Use an absolute path to an existing directory, e.g.:\n",
         "  guttman_file = file.path(getwd(), \"guttman_ordered.xlsx\")",
         call. = FALSE)
  if (file.access(dir_path, 2L) != 0L)
    stop("No write permission for directory: ", dir_path, "\n",
         "Use an absolute path to a writable directory, e.g.:\n",
         "  guttman_file = file.path(getwd(), \"guttman_ordered.xlsx\")",
         call. = FALSE)
  invisible(TRUE)
}


# Package-level mutable state
.pkg_state <- new.env(parent = emptyenv())
.pkg_state$erm_patched <- FALSE
