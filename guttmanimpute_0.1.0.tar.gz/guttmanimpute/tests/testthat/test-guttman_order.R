test_that("guttman_order sorts rows and columns correctly", {
  mat <- matrix(
    c(5, 1, 3,
      2, 4, 1,
      3, 3, 4),
    nrow = 3, byrow = TRUE,
    dimnames = list(c("P1", "P2", "P3"), c("I1", "I2", "I3"))
  )
  gmat <- guttman_order(mat)

  # Row totals: P1=9, P3=10, P2=7  -> order: P3, P1, P2
  expect_equal(rownames(gmat)[1], "P3")
  expect_equal(rownames(gmat)[3], "P2")

  # Column totals in Guttman-row order should also be decreasing
  col_tots <- colSums(gmat)
  expect_true(all(diff(col_tots) <= 0))
})

test_that("guttman_order attaches correct attributes", {
  mat  <- matrix(sample(1:5, 30, replace = TRUE), nrow = 6,
                 dimnames = list(paste0("P", 1:6), paste0("I", 1:5)))
  gmat <- guttman_order(mat)

  expect_true(!is.null(attr(gmat, "orig_row_order")))
  expect_true(!is.null(attr(gmat, "orig_col_order")))
  expect_equal(sort(attr(gmat, "orig_row_order")), sort(rownames(gmat)))
  expect_equal(sort(attr(gmat, "orig_col_order")), sort(colnames(gmat)))
})

test_that("restore_order recovers the original matrix exactly", {
  set.seed(7)
  mat  <- matrix(sample(1:5, 40, replace = TRUE), nrow = 8,
                 dimnames = list(paste0("P", 1:8), paste0("I", 1:5)))
  gmat <- guttman_order(mat)
  expect_identical(restore_order(gmat), mat)
})

test_that("restore_order errors without attributes", {
  plain <- matrix(1:9, 3, 3)
  expect_error(restore_order(plain), "orig_row_order")
})

test_that("guttman_order assigns names when absent", {
  mat  <- matrix(sample(1:5, 20, replace = TRUE), nrow = 4)
  gmat <- guttman_order(mat)
  expect_true(all(grepl("^P", rownames(gmat))))
  expect_true(all(grepl("^I", colnames(gmat))))
})
