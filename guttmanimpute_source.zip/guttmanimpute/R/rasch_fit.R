#' Fit a Partial Credit Model and Return Person and Item Fit Statistics
#'
#' Fits a Partial Credit Model (PCM) to a Guttman-ordered ordinal response
#' matrix using conditional maximum likelihood estimation via [eRm::PCM()],
#' then computes Outfit and Infit mean-square (MSQ) statistics and their
#' standardised *z*-scores for both persons and items.
#'
#' @section Singularity handling:
#' The error `"Lapack routine dgesv: system is exactly singular: U[k,k] = 0"`
#' originates inside `eRm::PCM()` at the lines:
#' ```
#' se.eta  <- sqrt(diag(solve(parest$hessian)))
#' se.beta <- sqrt(diag(lres$W %*% solve(parest$hessian) %*% t(lres$W)))
#' ```
#' `parest` is the raw `nlm()` output from the CML optimiser. When the
#' Hessian of the log-likelihood is rank-deficient -- common with real
#' polytomous datasets that have skewed or sparse category use after Guttman
#' ordering -- `solve()` raises the Lapack error.
#'
#' On the first call to [rasch_fit()], the package applies a one-time patch
#' to `eRm::PCM` via [assignInNamespace()], replacing the two `solve()` calls
#' with a single pre-computed robust inverse `.H_inv` using a three-stage
#' fallback:
#' \enumerate{
#'   \item `base::solve(H)` -- unchanged behaviour when well-conditioned.
#'   \item Ridge: `base::solve(H + lambda*I)` for
#'     `lambda` in `{1e-6, 1e-5, ..., 1e-1}`.
#'   \item Moore-Penrose pseudoinverse via `base::svd(H)`.
#' }
#' The patch is idempotent (applied at most once per R session).
#'
#' @param guttman_mat A numeric matrix of ordinal responses in Guttman order
#'   (as returned by [guttman_order()]). Responses need **not** be
#'   zero-indexed; the function shifts them internally before passing to
#'   [eRm::PCM()].
#'
#' @return A named list with four elements:
#' \describe{
#'   \item{`person_fit`}{Data frame (one row per person) with columns
#'     `OutfitMSQ`, `InfitMSQ`, `OutfitZ`, `InfitZ`.}
#'   \item{`item_fit`}{Data frame (one row per item) with columns
#'     `OutfitMSQ`, `InfitMSQ`, `OutfitZ`, `InfitZ`.}
#'   \item{`pcm_model`}{The fitted `eRm` model object.}
#'   \item{`person_params`}{The `ppar` person-parameter object.}
#' }
#'
#' @examples
#' set.seed(42)
#' dat  <- matrix(sample(1:5, 120, replace = TRUE), nrow = 24,
#'                dimnames = list(paste0("P", 1:24), paste0("I", 1:5)))
#' gmat <- guttman_order(dat)
#' fit  <- rasch_fit(gmat)
#' head(fit$person_fit)
#' fit$item_fit
#'
#' @importFrom utils assignInNamespace
#' @export
rasch_fit <- function(guttman_mat) {

  mat <- .to_matrix(guttman_mat)

  # Shift to 0-based coding required by eRm
  min_resp <- min(mat, na.rm = TRUE)
  mat_erm  <- mat - min_resp

  # Apply one-time patch to eRm::PCM (idempotent; no-op after first call)
  .patch_erm_pcm()

  pcm_model     <- eRm::PCM(mat_erm)
  person_params <- eRm::person.parameter(pcm_model)

  person_fit_raw <- suppressWarnings(eRm::personfit(person_params))
  item_fit_raw   <- suppressWarnings(eRm::itemfit(person_params))

  person_fit_df <- data.frame(
    OutfitMSQ = person_fit_raw$p.outfitMSQ,
    InfitMSQ  = person_fit_raw$p.infitMSQ,
    OutfitZ   = person_fit_raw$p.outfitZ,
    InfitZ    = person_fit_raw$p.infitZ,
    row.names = names(person_fit_raw$p.outfitMSQ),
    stringsAsFactors = FALSE
  )

  item_fit_df <- data.frame(
    OutfitMSQ = item_fit_raw$i.outfitMSQ,
    InfitMSQ  = item_fit_raw$i.infitMSQ,
    OutfitZ   = item_fit_raw$i.outfitZ,
    InfitZ    = item_fit_raw$i.infitZ,
    row.names = names(item_fit_raw$i.outfitMSQ),
    stringsAsFactors = FALSE
  )

  list(
    person_fit    = person_fit_df,
    item_fit      = item_fit_df,
    pcm_model     = pcm_model,
    person_params = person_params
  )
}


#' Identify Misfitting Persons or Items from a Fit Data Frame
#'
#' Flags rows of a fit data frame as misfitting when at least one MSQ
#' statistic falls **outside** the acceptable range `[msq_lower, msq_upper]`
#' **and** the corresponding standardised *z*-score exceeds `z_threshold` in
#' absolute value.
#'
#' @param fit_df A data frame with columns `OutfitMSQ`, `InfitMSQ`,
#'   `OutfitZ`, `InfitZ` (as produced by [rasch_fit()]).
#' @param msq_lower Numeric scalar. Lower bound of the acceptable MSQ range
#'   (default `0.8`).
#' @param msq_upper Numeric scalar. Upper bound of the acceptable MSQ range
#'   (default `1.2`).
#' @param z_threshold Numeric scalar. Absolute *z*-score threshold
#'   (default `1.96`, approx two-tailed p < 0.05).
#'
#' @return A character vector of row names (person or item IDs) that satisfy
#'   the misfit criteria.  Returns `character(0)` if no misfits are found.
#'
#' @examples
#' set.seed(42)
#' dat  <- matrix(sample(1:5, 120, replace = TRUE), nrow = 24,
#'                dimnames = list(paste0("P", 1:24), paste0("I", 1:5)))
#' gmat <- guttman_order(dat)
#' fit  <- rasch_fit(gmat)
#' identify_misfit(fit$person_fit)
#' identify_misfit(fit$item_fit, msq_lower = 0.7, msq_upper = 1.3)
#'
#' @export
identify_misfit <- function(fit_df,
                             msq_lower   = 0.8,
                             msq_upper   = 1.2,
                             z_threshold = 1.96) {

  .validate_thresholds(msq_lower, msq_upper, z_threshold)

  msq_flag <- (fit_df$OutfitMSQ < msq_lower | fit_df$OutfitMSQ > msq_upper |
               fit_df$InfitMSQ  < msq_lower | fit_df$InfitMSQ  > msq_upper)

  z_flag   <- (abs(fit_df$OutfitZ) > z_threshold |
               abs(fit_df$InfitZ)  > z_threshold)

  rownames(fit_df)[msq_flag & z_flag]
}


# =============================================================================
# Internal: one-time patch of eRm::PCM
# =============================================================================

# .patch_erm_pcm()
#
# Rewrites lines 23-25 of eRm::PCM:
#
#   ORIGINAL (lines 23-24-25):
#     se.eta  <- sqrt(diag(solve(parest$hessian)))
#     se.beta <- sqrt(diag(lres$W %*% solve(parest$hessian) %*%
#                 t(lres$W)))
#
#   PATCHED (3 replacement lines):
#     .dgesv_patch_applied <- TRUE
#     .H_inv  <- <robust_solve>(parest$hessian)
#     se.eta  <- sqrt(diag(.H_inv))
#     se.beta <- sqrt(diag(lres$W %*% .H_inv %*% t(lres$W)))
#
# The robust solve uses:
#   1. base::solve(H)               -- unchanged when well-conditioned
#   2. base::solve(H + lambda*I)    -- ridge, lambda 1e-6 to 1e-1
#   3. SVD pseudoinverse            -- Moore-Penrose last resort
#
# Idempotency: detected by the presence of '.dgesv_patch_applied' in the
# deparsed function body (a variable assignment survives deparse/parse;
# ## comments do not).
#
# @keywords internal
.patch_erm_pcm <- function() {

  if (.pkg_state$erm_patched) return(invisible(NULL))

  ns      <- asNamespace("eRm")
  orig_fn <- get("PCM", envir = ns)
  src     <- deparse(body(orig_fn))

  # Idempotency guard
  if (any(grepl(".dgesv_patch_applied", src, fixed = TRUE))) {
    .pkg_state$erm_patched <- TRUE
    return(invisible(NULL))
  }

  # Locate the two lines that contain solve(parest$hessian)
  line_eta  <- "        se.eta <- sqrt(diag(solve(parest$hessian)))"
  line_beta <- "        se.beta <- sqrt(diag(lres$W %*% solve(parest$hessian) %*% "

  idx_eta  <- which(src == line_eta)
  idx_beta <- which(src == line_beta)

  if (length(idx_eta) != 1L || length(idx_beta) != 1L ||
      idx_beta != idx_eta + 1L) {
    warning(
      "[guttmanimpute] Could not locate solve(parest$hessian) lines in ",
      "eRm::PCM (eRm version may have changed). ",
      "Singular-Hessian protection is NOT active.",
      call. = FALSE
    )
    .pkg_state$erm_patched <- TRUE
    return(invisible(NULL))
  }

  # idx_beta spans two source lines (idx_beta and idx_beta+1)
  idx_beta_end <- idx_beta + 1L   # "            t(lres$W)))"

  # Replacement: compute .H_inv once, reuse in both se.eta and se.beta.
  # Inline robust solve -- no external bindings needed.
  new_H_inv <- paste0(
    "        .dgesv_patch_applied <- TRUE; ",
    ".H_inv <- local({",
    "H <- parest$hessian; ",
    "r <- tryCatch(base::solve(H), error = function(.e) {",
    "if (!grepl('singular|dgesv', .e$message, ignore.case = TRUE)) stop(.e); ",
    "n <- nrow(H); res <- NULL; ",
    "for (.l in 10^seq(-6, -1)) {",
    "res <- tryCatch(base::solve(H + diag(.l, n)), error = function(e) NULL); ",
    "if (!is.null(res)) break}; ",
    "if (is.null(res)) {",
    ".s <- base::svd(H); ",
    ".t <- max(dim(H)) * .Machine$double.eps * max(.s$d); ",
    "res <- .s$v %*% diag(ifelse(.s$d > .t, 1/.s$d, 0), length(.s$d)) %*% t(.s$u)}; ",
    "res}); r})"
  )
  new_eta  <- "        se.eta  <- sqrt(pmax(diag(.H_inv), 0))"
  new_beta <- "        se.beta <- sqrt(pmax(diag(lres$W %*% .H_inv %*% t(lres$W)), 0))"

  # Replace lines idx_eta : idx_beta_end with four new lines
  before   <- src[seq_len(idx_eta - 1L)]
  after    <- src[seq(idx_beta_end + 1L, length(src))]
  patched_src <- c(before, new_H_inv, new_eta, new_beta, after)

  new_body <- tryCatch(
    parse(text = paste(patched_src, collapse = "\n"))[[1L]],
    error = function(e) {
      warning(
        "[guttmanimpute] Failed to parse patched eRm::PCM: ",
        conditionMessage(e),
        ". Singular-Hessian protection is NOT active.",
        call. = FALSE
      )
      NULL
    }
  )

  if (!is.null(new_body)) {
    patched_fn       <- orig_fn
    body(patched_fn) <- new_body
    assignInNamespace("PCM", patched_fn, ns = ns)
  }

  .pkg_state$erm_patched <- TRUE
  invisible(NULL)
}
