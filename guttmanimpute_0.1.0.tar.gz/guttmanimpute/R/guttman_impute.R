#' Targeted Guttman-Scale Imputation of Misfit Ordinal Responses
#'
#' The main user-facing function. Executes the complete pipeline:
#'
#' 1. Extracts the person-ID column (specified by `id_col`) and uses it as
#'    row names throughout — so IDs appear correctly in all outputs and saved
#'    files.
#' 2. Rearranges the response matrix into **Guttman order** (rows by
#'    descending person total scores, columns by descending item total scores).
#'    The output has the **same dimensions** as the input.
#' 3. Fits a **Partial Credit Model** (PCM) and extracts Outfit/Infit MSQ
#'    statistics and standardised *z*-scores.
#' 4. Identifies **misfit persons and items** (MSQ outside
#'    `[msq_lower, msq_upper]` and |*z*| > `z_threshold`).
#' 5. Replaces cells at the **intersection of misfit persons × items** with
#'    the nearest integer to the neighbourhood average (radius `k`).
#' 6. Returns the imputed matrix in the **original row/column order** — only
#'    targeted cells differ from the input.
#' 7. Optionally saves both matrices to XLSX or CSV.
#'
#' @section Why `id_col` is required:
#' Without a person-ID column the saved Guttman file shows meaningless row
#' numbers (`1`, `2`, …) instead of real student/respondent IDs, and the
#' imputed file cannot be matched back to the original records.  Specifying
#' `id_col` ensures:
#' \itemize{
#'   \item The Guttman-ordered file lists real IDs in descending-score order.
#'   \item The imputed file lists real IDs in the original data order.
#'   \item All in-memory matrices (`$guttman_data`, `$imputed_data`) use real
#'     IDs as row names.
#' }
#'
#' @section Output dimensions:
#' Both saved files and in-memory matrices always preserve the full
#' `n_persons × n_items` dimensions of the input (excluding the ID column):
#' \itemize{
#'   \item **Guttman data**: rows sorted by descending person total, columns
#'     by descending item total.
#'   \item **Imputed data**: original row and column order; only
#'     misfit-intersection cells are changed.
#' }
#'
#' @param data A data frame or numeric matrix of ordinal responses.  Must
#'   include a person-ID column identified by `id_col`.  All other columns
#'   are treated as item responses and must be numeric.
#' @param id_col **Required.** Column name (character) or column index
#'   (integer) of the person-ID column in `data`.  The IDs in this column
#'   become row names of all output matrices and the first column of all
#'   saved files.
#' @param msq_lower Numeric scalar >= 0. Lower bound of the acceptable
#'   Outfit/Infit MSQ range.  Default: `0.8`.
#' @param msq_upper Numeric scalar > `msq_lower`. Upper bound.
#'   Default: `1.2`.
#' @param z_threshold Numeric scalar > 0. Absolute standardised *z*-score
#'   threshold.  Default: `1.96` (approx two-tailed p < .05).
#' @param k Positive integer. Neighbourhood radius (`k = 1` gives a 3 × 3
#'   window with up to 8 neighbours).  Default: `1`.
#' @param save_guttman Logical. Save the Guttman-ordered matrix?
#'   Default: `FALSE`.
#' @param save_imputed Logical. Save the imputed matrix?  Default: `FALSE`.
#' @param guttman_file File path for the Guttman-ordered output.  Use `.xlsx`
#'   for Excel or `.csv` for plain text.
#'   Default: `"guttman_ordered.xlsx"`.
#' @param imputed_file File path for the imputed output.
#'   Default: `"imputed_data.xlsx"`.
#' @param verbose Logical. Print progress messages?  Default: `TRUE`.
#'
#' @return An object of class `"guttman_impute"` — a named list:
#' \describe{
#'   \item{`imputed_data`}{Numeric matrix, original row/column order, real
#'     person IDs as row names, only misfit-intersection cells changed.}
#'   \item{`guttman_data`}{Numeric matrix, Guttman order, real person IDs
#'     as row names.}
#'   \item{`imputed_guttman`}{Numeric matrix, Guttman order, post-imputation.}
#'   \item{`person_fit`}{Data frame of person Outfit/Infit MSQ and z-scores.}
#'   \item{`item_fit`}{Data frame of item Outfit/Infit MSQ and z-scores.}
#'   \item{`misfit_persons`}{Character vector of misfit person IDs.}
#'   \item{`misfit_items`}{Character vector of misfit item IDs.}
#'   \item{`imputed_log`}{Data frame: `person`, `item`, `guttman_row`,
#'     `guttman_col`, `old_value`, `new_value`, `n_neighbours`.}
#'   \item{`params`}{Named list of threshold parameters used.}
#' }
#'
#' @examples
#' set.seed(42)
#' dat <- data.frame(
#'   StudentID = paste0("S", 1:30),
#'   matrix(sample(1:5, 150, replace = TRUE), nrow = 30,
#'          dimnames = list(NULL, paste0("I", 1:5))),
#'   stringsAsFactors = FALSE, check.names = FALSE
#' )
#'
#' result <- guttman_impute(dat, id_col = "StudentID")
#'
#' # Real IDs in all outputs
#' head(rownames(result$guttman_data))
#' head(rownames(result$imputed_data))
#'
#' # Dimensions always preserved (n_persons x n_items, excluding ID col)
#' stopifnot(nrow(result$guttman_data) == 30L)
#' stopifnot(ncol(result$guttman_data) == 5L)
#'
#' # Save with absolute paths
#' \dontrun{
#' guttman_impute(dat, id_col = "StudentID",
#'                save_guttman = TRUE,
#'                guttman_file = file.path(getwd(), "guttman.xlsx"),
#'                save_imputed = TRUE,
#'                imputed_file = file.path(getwd(), "imputed.xlsx"))
#' }
#'
#' @export
guttman_impute <- function(data,
                            id_col,
                            msq_lower    = 0.8,
                            msq_upper    = 1.2,
                            z_threshold  = 1.96,
                            k            = 1,
                            save_guttman = FALSE,
                            save_imputed = FALSE,
                            guttman_file = "guttman_ordered.xlsx",
                            imputed_file = "imputed_data.xlsx",
                            verbose      = TRUE) {

  # ── Validate inputs ──────────────────────────────────────────────────────
  if (missing(id_col))
    stop(
      "`id_col` is required. Specify the column name or index of your ",
      "person-ID column, e.g.:\n",
      "  guttman_impute(dat, id_col = \"StudentID\")\n",
      "  guttman_impute(dat, id_col = 1)",
      call. = FALSE
    )

  .validate_thresholds(msq_lower, msq_upper, z_threshold)

  if (!is.numeric(k) || length(k) != 1L || k < 1 || k != round(k))
    stop("`k` must be a single positive integer.", call. = FALSE)

  # ── Extract ID column ────────────────────────────────────────────────────
  # Remove the ID column from data and capture IDs as a character vector.
  # These IDs become row names throughout the entire pipeline.
  extracted <- .extract_id_col(data, id_col)
  ids        <- extracted$ids      # character vector, length = n_persons
  data_items <- extracted$data     # data frame / matrix without ID column

  if (verbose && !is.null(ids))
    message("[guttmanimpute] Using '",
            if (is.character(id_col)) id_col else paste0("column ", id_col),
            "' as person IDs (", length(ids), " persons).")

  # ── Coerce to numeric matrix with real IDs as row names ──────────────────
  mat <- .to_matrix(data_items, ids = ids)

  if (verbose)
    message("[guttmanimpute] Data: ", nrow(mat), " persons x ",
            ncol(mat), " items.")

  # ── Orientation check ────────────────────────────────────────────────────
  if (ncol(mat) > nrow(mat)) {
    if (verbose)
      message(
        "[guttmanimpute] Input has ", nrow(mat), " rows x ", ncol(mat),
        " columns.\n",
        "  Persons appear to be stored as COLUMNS. Transposing automatically.\n",
        "  To suppress: transpose your data before calling guttman_impute().")
    mat <- t(mat)
  }

  # ── Step 1: Guttman ordering ─────────────────────────────────────────────
  if (verbose) message("[1/5] Applying Guttman ordering...")
  guttman_mat <- guttman_order(mat)

  # ── Step 2: Rasch PCM fit ────────────────────────────────────────────────
  if (verbose) message("[2/5] Fitting Partial Credit Model (PCM) via eRm...")
  fit_results <- rasch_fit(guttman_mat)

  # ── Step 3: Misfit detection ─────────────────────────────────────────────
  if (verbose) message("[3/5] Identifying misfit persons and items...")
  misfit_persons <- identify_misfit(fit_results$person_fit,
                                    msq_lower, msq_upper, z_threshold)
  misfit_items   <- identify_misfit(fit_results$item_fit,
                                    msq_lower, msq_upper, z_threshold)

  # ── Step 4: Targeted imputation ──────────────────────────────────────────
  if (verbose) message("[4/5] Imputing misfit-intersection cells...")
  imputed_guttman <- impute_guttman(guttman_mat, misfit_persons,
                                    misfit_items, k = k)
  imputed_log <- attr(imputed_guttman, "imputed_log")

  # ── Step 5: Restore original order ──────────────────────────────────────
  if (verbose) message("[5/5] Restoring original row/column order...")
  imputed_data <- restore_order(imputed_guttman)

  # ── Dimension and identity checks ────────────────────────────────────────
  if (!identical(dim(imputed_data), dim(mat)))
    stop("[guttmanimpute] BUG: imputed_data dimensions differ from input.",
         call. = FALSE)
  if (!identical(rownames(imputed_data), rownames(mat)))
    stop("[guttmanimpute] BUG: imputed_data rownames differ from input.",
         call. = FALSE)
  if (!identical(colnames(imputed_data), colnames(mat)))
    stop("[guttmanimpute] BUG: imputed_data colnames differ from input.",
         call. = FALSE)

  # ── Optional file output ─────────────────────────────────────────────────
  if (save_guttman) {
    .save_matrix(guttman_mat, guttman_file)
    if (verbose) message("  Guttman-ordered data saved to: ", guttman_file)
  }
  if (save_imputed) {
    .save_matrix(imputed_data, imputed_file)
    if (verbose) message("  Imputed data saved to: ", imputed_file)
  }

  # ── Assemble result object ───────────────────────────────────────────────
  result <- structure(
    list(
      imputed_data    = imputed_data,
      guttman_data    = guttman_mat,
      imputed_guttman = imputed_guttman,
      person_fit      = fit_results$person_fit,
      item_fit        = fit_results$item_fit,
      misfit_persons  = misfit_persons,
      misfit_items    = misfit_items,
      imputed_log     = imputed_log,
      params          = list(
        msq_lower   = msq_lower,
        msq_upper   = msq_upper,
        z_threshold = z_threshold,
        k           = k
      )
    ),
    class = "guttman_impute"
  )

  if (verbose) .print_summary(result)
  invisible(result)
}


# =============================================================================
# File save helper
# =============================================================================

# .save_matrix(mat, file)
#
# Saves a matrix to XLSX or CSV.  Row names (person IDs) become the first
# column named "PersonID".  No phantom unnamed row-name column is written.
.save_matrix <- function(mat, file) {

  .validate_save_path(file)

  df <- data.frame(
    PersonID = rownames(mat),
    as.data.frame(mat, check.names = FALSE),
    check.names    = FALSE,
    stringsAsFactors = FALSE
  )

  ext <- tolower(tools::file_ext(file))

  if (ext == "xlsx") {
    if (!requireNamespace("openxlsx", quietly = TRUE)) {
      warning("'openxlsx' not installed. Saving as CSV instead.", call. = FALSE)
      file <- sub("\\.xlsx$", ".csv", file, ignore.case = TRUE)
      utils::write.csv(df, file = file, row.names = FALSE)
    } else {
      openxlsx::write.xlsx(df, file = file, rowNames = FALSE, overwrite = TRUE)
    }
  } else {
    utils::write.csv(df, file = file, row.names = FALSE)
  }

  invisible(file)
}


# =============================================================================
# S3 methods
# =============================================================================

#' Print a `guttman_impute` Object
#' @param x A `guttman_impute` object.
#' @param ... Ignored.
#' @return `x`, invisibly.
#' @export
print.guttman_impute <- function(x, ...) {
  .print_summary(x)
  invisible(x)
}

#' Summarise a `guttman_impute` Object
#' @param object A `guttman_impute` object.
#' @param ... Ignored.
#' @return `object`, invisibly.
#' @export
summary.guttman_impute <- function(object, ...) {

  cat("\n=== guttmanimpute: Imputation Summary ===\n\n")
  cat("Dataset            :", nrow(object$imputed_data), "persons x",
      ncol(object$imputed_data), "items\n")
  cat("Guttman data       :", nrow(object$guttman_data), "x",
      ncol(object$guttman_data),
      " (sorted by row/col totals; real IDs preserved)\n")
  cat("Imputed data       :", nrow(object$imputed_data), "x",
      ncol(object$imputed_data),
      " (original order; only misfit-intersection cells changed)\n\n")

  cat("Thresholds:\n")
  cat("  MSQ range :", object$params$msq_lower, "to", object$params$msq_upper, "\n")
  cat("  |z|       :", object$params$z_threshold, "\n")
  cat("  k         :", object$params$k, "\n\n")

  cat("--- Person Fit ---\n");  print(round(object$person_fit, 4))
  cat("\n--- Item Fit ---\n");   print(round(object$item_fit, 4))

  cat("\nMisfit persons (", length(object$misfit_persons), "):",
      if (length(object$misfit_persons)) paste(object$misfit_persons, collapse=", ") else "none", "\n")
  cat("Misfit items   (", length(object$misfit_items), "):",
      if (length(object$misfit_items)) paste(object$misfit_items, collapse=", ") else "none", "\n")

  cat("\n--- Imputation Log (", nrow(object$imputed_log), "cells) ---\n")
  if (nrow(object$imputed_log) == 0L) cat("  No cells imputed.\n")
  else print(object$imputed_log)

  invisible(object)
}

.print_summary <- function(x) {
  n_imp <- nrow(x$imputed_log)
  cat("\n--- guttmanimpute results ---\n")
  cat("  Persons        :", nrow(x$imputed_data), "\n")
  cat("  Items          :", ncol(x$imputed_data), "\n")
  cat("  MSQ range      :", x$params$msq_lower, "to", x$params$msq_upper, "\n")
  cat("  Misfit persons :", length(x$misfit_persons),
      if (length(x$misfit_persons))
        paste0("(", paste(x$misfit_persons, collapse=", "), ")") else "", "\n")
  cat("  Misfit items   :", length(x$misfit_items),
      if (length(x$misfit_items))
        paste0("(", paste(x$misfit_items, collapse=", "), ")") else "", "\n")
  cat("  Cells imputed  :", n_imp, "\n")
  if (n_imp > 0L) {
    cat("  Changed cells  :\n")
    print(x$imputed_log[, c("person", "item", "old_value", "new_value")])
  }
  cat("-----------------------------\n")
}
