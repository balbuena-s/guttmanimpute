#' Targeted Imputation of Misfit Cells in a Guttman-Ordered Matrix
#'
#' Replaces every ordinal response at the intersection of a misfit person
#' (row) and a misfit item (column) with the nearest integer to the average
#' of its surrounding neighbours in the Guttman scalogram.
#'
#' The imputation formula (Balbuena, 2024) is:
#'
#' \deqn{
#'   \hat{Y}_{ij} = \mathrm{round}\!\left(
#'     \frac{\displaystyle\sum_{m=i-k}^{i+k}\sum_{n=j-k}^{j+k} Y_{mn}
#'           \;-\; c_{ij}}{(2k+1)^2 - 1}
#'   \right)
#' }
#'
#' where \eqn{c_{ij}} is the target misfit cell and \eqn{k} controls the
#' neighbourhood radius (default \eqn{k = 1}, giving a 3 × 3 window with
#' up to 8 neighbours).
#'
#' Imputation proceeds **sequentially top-to-bottom, left-to-right**, so
#' already-imputed neighbours can inform subsequent replacements (consistent
#' with the paper's description).  Edge cells use however many valid
#' neighbours are available.
#'
#' @param guttman_mat A numeric matrix in Guttman order carrying
#'   `orig_row_order` and `orig_col_order` attributes (as returned by
#'   [guttman_order()]).
#' @param misfit_persons Character vector of person IDs (row names) identified
#'   as misfitting.
#' @param misfit_items Character vector of item IDs (column names) identified
#'   as misfitting.
#' @param k Positive integer. Neighbourhood radius (default `1`).  With
#'   `k = 1` the window is 3 × 3; with `k = 2` it is 5 × 5, etc.
#'
#' @return A numeric matrix of the same dimensions and order as `guttman_mat`,
#'   with misfit-intersection cells replaced.  Three additional attributes are
#'   attached:
#'   \describe{
#'     \item{`orig_row_order`}{Inherited from `guttman_mat`.}
#'     \item{`orig_col_order`}{Inherited from `guttman_mat`.}
#'     \item{`imputed_log`}{Data frame recording every imputed cell with
#'       columns `person`, `item`, `guttman_row`, `guttman_col`,
#'       `old_value`, `new_value`, `n_neighbours`.}
#'   }
#'
#' @references
#' Balbuena, S. E. (2024). A method for imputing ordinal responses from the
#' intersection of misfitting items and persons in a Guttman scale.
#' *Manuscript submitted for publication.*
#'
#' @examples
#' set.seed(42)
#' dat  <- matrix(sample(1:5, 120, replace = TRUE), nrow = 24,
#'                dimnames = list(paste0("P", 1:24), paste0("I", 1:5)))
#' gmat <- guttman_order(dat)
#' fit  <- rasch_fit(gmat)
#' mp   <- identify_misfit(fit$person_fit)
#' mi   <- identify_misfit(fit$item_fit)
#' imp  <- impute_guttman(gmat, mp, mi)
#' attr(imp, "imputed_log")
#'
#' @export
impute_guttman <- function(guttman_mat,
                            misfit_persons,
                            misfit_items,
                            k = 1) {

  mat <- .to_matrix(guttman_mat)

  # Propagate ordering attributes
  orig_row <- attr(guttman_mat, "orig_row_order")
  orig_col <- attr(guttman_mat, "orig_col_order")

  if (is.null(orig_row) || is.null(orig_col)) {
    stop(
      "`guttman_mat` must carry `orig_row_order` and `orig_col_order` ",
      "attributes.  Pass the output of `guttman_order()`.",
      call. = FALSE
    )
  }

  if (!is.numeric(k) || length(k) != 1L || k < 1L || k != round(k)) {
    stop("`k` must be a single positive integer.", call. = FALSE)
  }

  # Early exit when nothing to impute
  if (length(misfit_persons) == 0L || length(misfit_items) == 0L) {
    message("[guttmanimpute] No intersection cells to impute ",
            "(no misfit persons or no misfit items).")
    attr(mat, "orig_row_order") <- orig_row
    attr(mat, "orig_col_order") <- orig_col
    attr(mat, "imputed_log")    <- .empty_log()
    return(mat)
  }

  n_rows <- nrow(mat)
  n_cols <- ncol(mat)

  misfit_rows <- which(rownames(mat) %in% misfit_persons)
  misfit_cols <- which(colnames(mat) %in% misfit_items)

  if (length(misfit_rows) == 0L) {
    warning("None of the `misfit_persons` matched row names in `guttman_mat`.",
            call. = FALSE)
  }
  if (length(misfit_cols) == 0L) {
    warning("None of the `misfit_items` matched column names in `guttman_mat`.",
            call. = FALSE)
  }

  # All intersection cells ordered top-to-bottom, left-to-right
  target_cells <- expand.grid(row = sort(misfit_rows),
                               col = sort(misfit_cols))
  target_cells <- target_cells[order(target_cells$row, target_cells$col), ]

  imputed_mat <- mat
  log_rows    <- vector("list", nrow(target_cells))

  for (t in seq_len(nrow(target_cells))) {

    i <- target_cells$row[t]
    j <- target_cells$col[t]

    # Window boundaries clamped to matrix edges
    row_min <- max(1L,      i - k)
    row_max <- min(n_rows,  i + k)
    col_min <- max(1L,      j - k)
    col_max <- min(n_cols,  j + k)

    window  <- imputed_mat[row_min:row_max, col_min:col_max, drop = FALSE]

    # Sum all window values then subtract the target cell
    win_sum <- sum(window, na.rm = TRUE) - imputed_mat[i, j]

    # Count valid (non-NA) cells in the window, excluding the target cell
    n_valid <- sum(!is.na(window)) -
               as.integer(!is.na(imputed_mat[i, j]))

    if (n_valid == 0L) {
      warning(sprintf(
        "[guttmanimpute] Cell (%s \u00d7 %s): no valid neighbours; skipped.",
        rownames(mat)[i], colnames(mat)[j]),
        call. = FALSE)
      next
    }

    new_val <- round(win_sum / n_valid)

    log_rows[[t]] <- data.frame(
      person       = rownames(mat)[i],
      item         = colnames(mat)[j],
      guttman_row  = i,
      guttman_col  = j,
      old_value    = imputed_mat[i, j],
      new_value    = new_val,
      n_neighbours = n_valid,
      stringsAsFactors = FALSE
    )

    imputed_mat[i, j] <- new_val
  }

  imputed_log <- do.call(rbind, Filter(Negate(is.null), log_rows))
  if (is.null(imputed_log)) imputed_log <- .empty_log()

  attr(imputed_mat, "orig_row_order") <- orig_row
  attr(imputed_mat, "orig_col_order") <- orig_col
  attr(imputed_mat, "imputed_log")    <- imputed_log

  imputed_mat
}


# ── Internal helpers ──────────────────────────────────────────────────────────

.empty_log <- function() {
  data.frame(
    person       = character(),
    item         = character(),
    guttman_row  = integer(),
    guttman_col  = integer(),
    old_value    = numeric(),
    new_value    = numeric(),
    n_neighbours = integer(),
    stringsAsFactors = FALSE
  )
}
