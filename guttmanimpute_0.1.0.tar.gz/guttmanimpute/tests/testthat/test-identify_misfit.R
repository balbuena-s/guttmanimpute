test_that("identify_misfit flags rows outside [0.8, 1.2] with |z| > 1.96", {
  fit_df <- data.frame(
    OutfitMSQ = c(1.5, 0.95, 0.6,  1.0),
    InfitMSQ  = c(1.4, 1.0,  0.65, 1.1),
    OutfitZ   = c(2.5, 0.5, -2.1,  1.0),
    InfitZ    = c(2.1, 0.3, -2.0,  0.8),
    row.names = c("P1", "P2", "P3", "P4")
  )

  result <- identify_misfit(fit_df)
  expect_true("P1" %in% result)   # MSQ > 1.2 AND |z| > 1.96
  expect_true("P3" %in% result)   # MSQ < 0.8 AND |z| > 1.96
  expect_false("P2" %in% result)  # MSQ ok
  expect_false("P4" %in% result)  # |z| not exceeded
})

test_that("identify_misfit respects custom thresholds", {
  fit_df <- data.frame(
    OutfitMSQ = c(1.25, 0.9),
    InfitMSQ  = c(1.20, 0.9),
    OutfitZ   = c(2.0,  1.0),
    InfitZ    = c(1.9,  1.0),
    row.names = c("I1", "I2")
  )

  # With default [0.8, 1.2]: I1 has MSQ = 1.25 > 1.2 and |z| > 1.96
  expect_equal(identify_misfit(fit_df), "I1")

  # With wider [0.7, 1.3]: neither item misfits on MSQ
  expect_equal(identify_misfit(fit_df, msq_lower = 0.7, msq_upper = 1.3),
               character(0))
})

test_that("identify_misfit validates inputs", {
  fit_df <- data.frame(OutfitMSQ = 1, InfitMSQ = 1,
                       OutfitZ = 0, InfitZ = 0,
                       row.names = "X")
  expect_error(identify_misfit(fit_df, msq_lower = -1))
  expect_error(identify_misfit(fit_df, msq_upper = 0.5))   # <= msq_lower
  expect_error(identify_misfit(fit_df, z_threshold = -1))
})
