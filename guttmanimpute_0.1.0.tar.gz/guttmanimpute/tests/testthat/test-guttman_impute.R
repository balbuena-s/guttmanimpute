# ── helpers ──────────────────────────────────────────────────────────────────

# Build a data.frame with a StudentID column + item columns
make_data <- function(n = 30, p = 5, seed = 42) {
  set.seed(seed)
  data.frame(
    StudentID = paste0("S", seq_len(n)),
    matrix(sample(1:5, n * p, replace = TRUE), nrow = n,
           dimnames = list(NULL, paste0("I", seq_len(p)))),
    stringsAsFactors = FALSE, check.names = FALSE
  )
}

run <- function(...) suppressWarnings(guttman_impute(..., verbose = FALSE))

# ── id_col requirement ────────────────────────────────────────────────────────

test_that("guttman_impute errors when id_col is missing", {
  dat <- make_data()
  expect_error(guttman_impute(dat, verbose = FALSE), "id_col.*required",
               ignore.case = TRUE)
})

test_that("guttman_impute accepts id_col as a column name", {
  dat    <- make_data()
  result <- run(dat, id_col = "StudentID")
  expect_equal(rownames(result$imputed_data), paste0("S", 1:30))
})

test_that("guttman_impute accepts id_col as a column index", {
  dat    <- make_data()
  result <- run(dat, id_col = 1L)
  expect_equal(rownames(result$imputed_data), paste0("S", 1:30))
})

test_that("guttman_impute errors on unknown id_col name", {
  dat <- make_data()
  expect_error(run(dat, id_col = "NOPE"), "not found")
})

# ── dimension guarantees ──────────────────────────────────────────────────────

test_that("guttman_data has n_persons rows and n_items columns (ID col excluded)", {
  dat    <- make_data(n = 30, p = 5)
  result <- run(dat, id_col = "StudentID")
  expect_equal(dim(result$guttman_data), c(30L, 5L))
})

test_that("imputed_data has n_persons rows and n_items columns (ID col excluded)", {
  dat    <- make_data(n = 30, p = 5)
  result <- run(dat, id_col = "StudentID")
  expect_equal(dim(result$imputed_data), c(30L, 5L))
})

test_that("guttman_data contains every person ID exactly once", {
  dat    <- make_data()
  result <- run(dat, id_col = "StudentID")
  expect_setequal(rownames(result$guttman_data), dat$StudentID)
})

# ── ordering correctness ──────────────────────────────────────────────────────

test_that("guttman_data rows sorted by descending person total score", {
  dat    <- make_data()
  result <- run(dat, id_col = "StudentID")
  totals <- rowSums(result$guttman_data)
  expect_true(all(diff(totals) <= 0))
})

test_that("guttman_data columns sorted by descending item total score", {
  dat    <- make_data()
  result <- run(dat, id_col = "StudentID")
  totals <- colSums(result$guttman_data)
  expect_true(all(diff(totals) <= 0))
})

test_that("imputed_data row order matches original data order", {
  dat    <- make_data()
  result <- run(dat, id_col = "StudentID")
  expect_identical(rownames(result$imputed_data), dat$StudentID)
})

test_that("imputed_data column order matches original item column order", {
  dat    <- make_data()
  result <- run(dat, id_col = "StudentID")
  item_cols <- setdiff(colnames(dat), "StudentID")
  expect_identical(colnames(result$imputed_data), item_cols)
})

# ── real IDs in saved files ───────────────────────────────────────────────────

test_that("saved guttman XLSX has real IDs in Guttman order, full n_persons rows", {
  dat   <- make_data(n = 30, p = 5)
  tmp_g <- tempfile(fileext = ".xlsx")
  result <- run(dat, id_col = "StudentID",
                save_guttman = TRUE, guttman_file = tmp_g)

  back <- openxlsx::read.xlsx(tmp_g)
  expect_equal(nrow(back), 30L)               # all 30 persons saved
  expect_equal(ncol(back), 6L)               # PersonID + 5 items
  expect_equal(colnames(back)[1], "PersonID")
  # PersonID column must match the Guttman row order (real IDs)
  expect_setequal(back$PersonID, dat$StudentID)
  expect_equal(back$PersonID, rownames(result$guttman_data))
})

test_that("saved imputed XLSX has real IDs in original order, full n_persons rows", {
  dat   <- make_data(n = 30, p = 5)
  tmp_i <- tempfile(fileext = ".xlsx")
  result <- run(dat, id_col = "StudentID",
                save_imputed = TRUE, imputed_file = tmp_i)

  back <- openxlsx::read.xlsx(tmp_i)
  expect_equal(nrow(back), 30L)
  expect_equal(ncol(back), 6L)
  # Must be in ORIGINAL data order, not Guttman order
  expect_equal(back$PersonID, dat$StudentID)
})

test_that("saved imputed CSV has real IDs in original order", {
  dat   <- make_data(n = 20, p = 4)
  tmp_i <- tempfile(fileext = ".csv")
  run(dat, id_col = "StudentID", save_imputed = TRUE, imputed_file = tmp_i)

  back <- read.csv(tmp_i, check.names = FALSE)
  expect_equal(nrow(back), 20L)
  expect_equal(back$PersonID, dat$StudentID)
})

# ── targeted imputation correctness ──────────────────────────────────────────

test_that("only misfit-intersection cells differ from original in imputed_data", {
  set.seed(1)
  mat <- matrix(sample(1:5, 300, replace = TRUE, prob = c(.5,.25,.12,.08,.05)),
                nrow = 60,
                dimnames = list(NULL, paste0("I", 1:5)))
  dat <- data.frame(ID = paste0("P", 1:60), mat,
                    stringsAsFactors = FALSE, check.names = FALSE)
  result <- run(dat, id_col = "ID",
                msq_lower = 0.5, msq_upper = 1.5, z_threshold = 1.0)

  # Dimension invariant
  expect_equal(dim(result$imputed_data), c(60L, 5L))

  # Item matrix before imputation (original order, no ID col)
  orig_mat <- as.matrix(dat[, -1])
  rownames(orig_mat) <- dat$ID

  changed <- which(orig_mat != result$imputed_data, arr.ind = TRUE)
  if (nrow(changed) > 0L) {
    expect_true(all(rownames(orig_mat)[changed[,1]] %in% result$misfit_persons))
    expect_true(all(colnames(orig_mat)[changed[,2]] %in% result$misfit_items))
  } else {
    expect_true(length(result$misfit_persons) == 0L |
                length(result$misfit_items)   == 0L)
  }
})

# ── orientation auto-transpose ────────────────────────────────────────────────

test_that("guttman_impute auto-transposes when item cols outnumber person rows", {
  set.seed(20)
  # 5 items x 40 persons — stored with persons as columns
  mat_t <- matrix(sample(1:5, 200, replace = TRUE), nrow = 5,
                  dimnames = list(paste0("I", 1:5), paste0("P", 1:40)))
  # Add a (transposed) ID col: row names become the ID
  df_t <- data.frame(ItemID = rownames(mat_t), as.data.frame(mat_t),
                     stringsAsFactors = FALSE, check.names = FALSE)
  # After stripping ItemID there are 5 rows x 40 cols -> auto-transpose
  result <- suppressMessages(suppressWarnings(
    guttman_impute(df_t, id_col = "ItemID", verbose = FALSE)))

  # After transpose: 40 persons, 5 items
  expect_equal(nrow(result$imputed_data), 40L)
  expect_equal(ncol(result$imputed_data),  5L)
})

# ── input validation ──────────────────────────────────────────────────────────

test_that("guttman_impute validates msq and z thresholds", {
  dat <- make_data()
  expect_error(run(dat, id_col="StudentID", msq_lower=-0.1), "msq_lower")
  expect_error(run(dat, id_col="StudentID", msq_upper=0.5),  "msq_upper")
  expect_error(run(dat, id_col="StudentID", z_threshold=0),  "z_threshold")
  expect_error(run(dat, id_col="StudentID", k=0),            "k")
})

# ── S3 methods ────────────────────────────────────────────────────────────────

test_that("print and summary methods work without error", {
  result <- run(make_data(), id_col = "StudentID")
  expect_output(print(result))
  expect_output(summary(result))
})

test_that("params list stores supplied threshold values", {
  result <- run(make_data(), id_col = "StudentID",
                msq_lower = 0.7, msq_upper = 1.3, z_threshold = 2.0, k = 2)
  expect_equal(result$params$msq_lower,   0.7)
  expect_equal(result$params$msq_upper,   1.3)
  expect_equal(result$params$z_threshold, 2.0)
  expect_equal(result$params$k,           2L)
})
