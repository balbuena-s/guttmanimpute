test_that(".extract_id_col extracts by column name", {
  df <- data.frame(ID = c("A","B","C"),
                   I1 = 1:3, I2 = 4:6, stringsAsFactors = FALSE)
  res <- .extract_id_col(df, "ID")
  expect_equal(res$ids, c("A","B","C"))
  expect_equal(ncol(res$data), 2L)
  expect_false("ID" %in% colnames(res$data))
})

test_that(".extract_id_col extracts by column index", {
  df <- data.frame(ID = c("X","Y"), I1 = 1:2, I2 = 3:4)
  res <- .extract_id_col(df, 1L)
  expect_equal(res$ids, c("X","Y"))
  expect_equal(ncol(res$data), 2L)
})

test_that(".extract_id_col errors on unknown column name", {
  df <- data.frame(I1 = 1:3, I2 = 4:6)
  expect_error(.extract_id_col(df, "NOPE"), "not found")
})

test_that(".extract_id_col returns NULL ids when id_col is NULL", {
  df <- data.frame(I1 = 1:3, I2 = 4:6)
  res <- .extract_id_col(df, NULL)
  expect_null(res$ids)
  expect_equal(ncol(res$data), 2L)
})

test_that(".to_matrix with ids sets correct rownames", {
  mat <- matrix(1:6, nrow = 2, dimnames = list(NULL, c("I1","I2","I3")))
  result <- .to_matrix(mat, ids = c("Alice","Bob"))
  expect_equal(rownames(result), c("Alice","Bob"))
  expect_equal(colnames(result), c("I1","I2","I3"))
})

test_that(".to_matrix preserves numeric-string rownames when no ids given", {
  df <- data.frame(matrix(sample(1:5, 15, replace=TRUE), nrow=3,
                          dimnames=list(NULL, paste0("I",1:5))))
  expect_equal(rownames(df), c("1","2","3"))
  result <- .to_matrix(df)
  expect_equal(rownames(result), c("1","2","3"))
})

test_that(".validate_save_path errors on non-existent directory", {
  bad <- file.path(tempdir(), "no_such_dir_xyz", "out.csv")
  expect_error(.validate_save_path(bad), "Directory does not exist")
})

test_that(".validate_save_path passes for a valid writable path", {
  good <- tempfile(fileext = ".csv")
  expect_true(.validate_save_path(good))
})
